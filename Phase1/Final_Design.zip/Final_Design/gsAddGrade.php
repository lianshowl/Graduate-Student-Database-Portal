<html>
<head>
<title>Search Result</title>
</head>

<body>

<?php

session_start();

$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password,$dbname);

if (!$conn) {
        die("Connection failed: ". mysqli_connect_error());
}

$grade =$_POST["grade"];
$sid = $_SESSION["sid"];
$crn = $_SESSION["crn"];
$sem = $_SESSION["sem"];
$yr = $_SESSION["yr"];

if($grade == 'A' || $grade == 'A-' || $grade == 'B+' || $grade == 'B' || $grade == 'B-' || $grade == 'C+' || $grade == 'C' || $grade == 'F' || $grade == 'IP'){
  $query = "UPDATE transcript SET grade='$grade' WHERE sid='$sid'
  AND crn='$crn' AND sem='$sem' AND yr='$yr'";

if (mysqli_query($conn, $query)) {
        echo "Grade added correctly";
}
else {
        echo "Grade not added" . mysqli_error($conn);
  }
}  
else{
  echo "Grade not added. Invalid grades as input. </br><h4>Valid grades are: A, A-, B+, B, B-, C+, C, F or IP.</h4>";
}
?>

<br>
<br>

<a href="gs.html">Return to Main Page</a>

</body>

</html>
