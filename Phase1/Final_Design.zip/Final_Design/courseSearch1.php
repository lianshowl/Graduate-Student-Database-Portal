<?php
session_start();
?> 

<?php

$dept = $_POST['dept'];
$courseNum = $_POST['courseNum'];

$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password,$dbname);
if (!$conn) {
die("Connection failed: ". mysqli_connect_error());
}

if($courseNum!=NULL){
$query = "SELECT courseOffer.crn,cday,startTime,endTime,sem,yr,dept,courseNum,title,numCredit,preReq1,preReq2
FROM courseOffer, catalog
WHERE catalog.dept='$dept' and catalog.courseNum='$courseNum'and catalog.crn=courseOffer.crn";
$result = mysqli_query($conn,$query);
if (mysqli_num_rows($result) > 0){
//output data of each row
while ($row = mysqli_fetch_assoc($result)){
echo "CRN: ".$row["crn"]. "<br> Title:" . $row["title"]." <br>".$row["dept"]. " " .$row["courseNum"]. "<br>";
echo "Credit Hours: ".$row["numCredit"]. "<br> Main Pre-Req:" . $row["preReq1"]."<br> Second Pre-Req:" .$row["preReq2"]. "<br>";
echo "Day: " . $row["cday"]. "<br>";
echo "Time:" . $row["startTime"]. "-". $row["endTime"]." <br>Term: ". $row["sem"]." " . $row["yr"]."<br>";
echo ("<form method='post' action='register.php'>");
$thisCRN=$row["crn"];

if($row["sem"]=="s" && $row[yr]=="19"){
echo("Click on the button with CRN below to add the course:<br> <input type='submit' value='$thisCRN' name='add' />");
}

$_SESSION["sem"]=$row["sem"];
$_SESSION["year"]=$row["yr"];


echo ("</form>");
echo "<hr>";
}
} else {
     echo "No class matched criteria";
  }
}

else{
$query = "SELECT courseOffer.crn,cday,startTime,endTime,sem,yr,dept,courseNum,title,numCredit,preReq1,preReq2
FROM courseOffer, catalog
WHERE catalog.dept='$dept'and catalog.crn=courseOffer.crn";
$result = mysqli_query($conn,$query);
if (mysqli_num_rows($result) > 0){
//output data of each row
while ($row = mysqli_fetch_assoc($result)){
echo "CRN: ".$row["crn"]. "<br> Title:" . $row["title"]." <br>".$row["dept"]. " " .$row["courseNum"]. "<br>";
echo "Credit Hours: ".$row["numCredit"]. "<br> Main Pre-Req:" . $row["preReq1"]."<br> Second Pre-Req:" .$row["preReq2"]. "<br>";
echo "Day: " . $row["cday"]. "<br>";
echo "Time:" . $row["startTime"]. "-". $row["endTime"]." <br>Term: ". $row["sem"]." " . $row["yr"]."<br>";
echo ("<form method='post' action='register.php'>");
$thisCRN=$row["crn"];

if($row["sem"]=="s" && $row[yr]=="19"){
echo("Click on the button with CRN below to add the course: <br><input type='submit' value='$thisCRN' name='add' />");
}
$_SESSION["sem"]=$row["sem"];
$_SESSION["year"]=$row["yr"];
echo ("</form>");
echo "<hr>";
}
} else {
     echo "No class matched criteria";
  }

}

mysqli_close($conn);
?>
<br>
<a href="main.html">Back to course search</a><br>
<a href="studentPortal.php">Back to Student Portal</a>
</body>
</html>

