<?php

session_start();

$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
die("Connection failed: ". mysqli_connect_error());
}
	if(isset($_POST['user'])){
		$id = $_POST['user'];
		$password = $_POST['psw'];

		// query the database for user
        $sql = "SELECT user,psw FROM facUsers WHERE user = '$id' 
            AND  psw = '$password' LIMIT 1";
        $result = mysqli_query($conn,$sql);
        //echo $result;
        while($row = mysqli_fetch_array($result)) {
            $success = true;
          }
        if($success==false){
          echo '<script>alert("The username or password are incorrect! Please try again.")</script>';
          echo '<script> window.location="facLogin.php"</script>';
        }
        else
        {
            $sql1 = "SELECT fid FROM facUsers WHERE user = '$id' AND  psw = '$password' LIMIT 1";
             $fid = mysqli_query($conn,$sql1);
             $row = mysqli_fetch_assoc($fid); 
             $_SESSION['fid'] = $row['fid'];
            echo '<script>alert("Login successful!")</script>';
            echo '<script> window.location="facPage.html"</script>'; //change this URL when we have faculty page
        }
       
    }

?>
