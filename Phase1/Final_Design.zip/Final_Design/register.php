<?php
session_start();
?>

<html>
<head>
<title>Class Registration</title>
</head>
<body>

<?php

$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password,$dbname);
if (!$conn) {
die("Connection failed: ". mysqli_connect_error());
}

$crn= $_POST['add'];
$sid=$_SESSION["sid"];
$sem=$_SESSION["sem"];
$yr=$_SESSION["year"];

/*
echo $crn;
echo $sem;
echo $yr;
echo $sid;
*/ 

$query = "select crn from transcript where transcript.crn='$crn'
and transcript.sid='$sid'";
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_assoc($result);
$fetchCrn=$row["crn"];
echo $fetchCrn;
if($fetchCrn!=NULL){
echo "You have already taken this class!<br>";
}
else {
$query = "select cday,startTime,endTime from courseOffer 
where courseOffer.crn='$crn' and
courseOffer.sem='$sem' and courseOffer.yr='$yr'";
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_assoc($result);
$day=$row["cday"];
$startTime=$row["startTime"];
$endTime=$row["endTime"];


//checking for time conflict
$query = "select cday,startTime,endTime from transcript,courseOffer 
where transcript.grade='IP' and transcript.sid='$sid' and
courseOffer.crn=transcript.crn and courseOffer.sem=transcript.sem and
courseOffer.yr=transcript.yr";
$result = mysqli_query($conn,$query);

$conflict=false;
if (mysqli_num_rows($result) > 0){
while ($row = mysqli_fetch_assoc($result)){
//checking for time conflict
$checkDay=$row["cday"];
$checkSTime=$row["startTime"];
$checkETime=$row["endTime"];
if ($checkDay==$day){

	if ($checkETime>$endTime){
		if ($checkSTime-$endTime<0.5){
		$conflict=true;
		}
	}
	else{
		if($startTime-$checkETime<0.5){
		$conflict=true;
		}
	}

}

}
} 

//checking for pre-reqs
$notElligible = true;
$pre_req_query = "SELECT * FROM catalog WHERE crn='$crn'";
$pre_req_result = mysqli_query($conn,$pre_req_query);
$transcript = "SELECT * FROM transcript WHERE
sid='$sid' AND (transcript.grade = 'A' OR transcript.grade ='A-' OR
transcript.grade ='B+' OR transcript.grade ='B'
OR transcript.grade ='B-' OR transcript.grade ='C+'OR transcript.grade ='C')";
$transcript_result = mysqli_query($conn,$transcript);
while($row1 = mysqli_fetch_assoc($pre_req_result)) {
        if ($row1["preReq1"] == NULL) {
                $notElligible = false;
        }
	else {
              	while ($row2 = mysqli_fetch_assoc($transcript_result)) {
                        if ($row1["preReq1"] == $row2["crn"]) {
                                $transcript2 = "SELECT * FROM transcript WHERE sid='$sid' AND 
				(transcript.grade = 'A' OR transcript.grade ='A-' OR
            			transcript.grade ='B+' OR transcript.grade ='B'
            			OR transcript.grade ='B-' OR transcript.grade ='C+'
            			OR transcript.grade ='C')";
                                $transcript_result2 = mysqli_query($conn,$transcript2);
                                while ($row3 = mysqli_fetch_assoc(($transcript_result2))) {
                                        if ($row1["preReq2"] == NULL || $row1["preReq2"] == $row3["crn"]) {
                                                $notElligible = false;
                                                break;
                                        }
                                }
                        }
                }
            }
        }


if($conflict==false && $notElligible ==false){
$query = "insert into transcript values('$sid','$crn','$sem','$yr','IP')";
$result = mysqli_query($conn,$query);
if($result){
echo "Course Successfully Added!<br>";
echo "CRN:" .$crn. "<br> Semester: " .$sem. " Year:" .$yr. "<br>";
}
else{
echo "Error";
}
}
else if($conflict==true){
echo "Sorry, this course has a time conflict with one of the courses you are taking";
if($notElligible==true){
echo "<br>You are also missing the required pre-reqs for this course";
}
}

else if($notElligible==true){
echo "<br>You are missing the required pre-reqs for this course";

}

}


mysqli_close($conn);
?>
<br>
<a href="main.html">Back to Course Search Page</a><br>
<a href="studentPortal.php">Back to Student Portal</a>
</body>
