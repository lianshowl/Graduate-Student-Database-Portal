<?php
session_start();
?>

<html>
<head>
<title>Class Registration</title>
</head>
<body>

<?php
$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
die("Connection failed: ". mysqli_connect_error());
}

$crn= $_POST["add"]; 
$sid=$_SESSION["sid"];

$sem=$_SESSION["sem"];
$yr=$_SESSION["year"];

// ------------------------
// Only part that you need
// ------------------------
$notElligible = true;
$pre_req_query = "SELECT * FROM catalog WHERE crn='$crn'";
$pre_req_result = mysqli_query($conn,$pre_req_query);
$transcript = "SELECT * FROM transcript WHERE
sid='$sid' AND grade!='IP'";
$transcript_result = mysqli_query($conn,$transcript);

while($row1 = mysqli_fetch_assoc($pre_req_result)) {
	if ($row1["preReq1"] == NULL) {
		$notElligible = false;
	}
	else {
		while ($row2 = mysqli_fetch_assoc($transcript_result)) {
			if ($row1["preReq1"] == $row2["crn"]) {
				$transcript2 = "SELECT * FROM transcript WHERE sid='$sid' AND grade!='IP'";
				$transcript_result2 = mysqli_query($conn,$transcript2);
				while ($row3 = mysqli_fetch_assoc(($transcript_result2))) {
					if ($row1["preReq2"] == NULL || $row1["preReq2"] == $row3["crn"]) {
						$notElligible = false;
						break;
					}
				}
			}
		}
	}
}

if ($notElligible == true) {
	echo "Student does not have necessary pre-requisites";
}
else {
	echo "Added class";
}

// ------------------------
// ------------------------

mysqli_close($conn);
?>
<br>
<a href="main.html">Back to Course Search Page</a>
</body>
</html>
