<?php
session_start();
?>

<html>
<head>
<title>Adding a Student to the System</title>
</head>
<body>

/*
<?php

$fnameErr = $lnameErr = $idErr = $ssnErr =$userErr==$pswErr "";

  if (empty($_POST["fname"])) {
    $fnameErr = "First name is required";
  } else {
    $fname = test_input($_POST["fname"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$fname)) {
      $fnameErr = "Only letters and white space allowed"; 
    }
  }
  

    if (empty($_POST["lname"])) {
    $lnameErr = "Last name is required";
  } else {
    $lname = test_input($_POST["lname"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$lname)) {
      $lnameErr = "Only letters and white space allowed"; 
    }
  }
  
  
     if (empty($_POST["user"])) {
    $userErr = "Username is required";
  } else {
    $user = test_input($_POST["user"]);
  }
  
       if (empty($_POST["psw"])) {
    $pswErr = "Password is required";
  } else {
    $psw = test_input($_POST["psw"]);
  }
  
         if (empty($_POST["sid"])) {
    $sidErr = "SID is required";
  } else {
    $sid = test_input($_POST["sid"]);
  }
  
         if (empty($_POST["ssn"])) {
    $ssnErr = "SSN is required";
  } else {
    $ssn = test_input($_POST["ssn"]);
  }
  


function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
*/

<?php

$fnameErr = $lnameErr = $idErr = $ssnErr =$userErr==$pswErr "";


$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password,$dbname);
if (!$conn) {
die("Connection failed: ". mysqli_connect_error());
}
echo "hi";

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$ssn = $_POST['ssn'];
$sid = $_POST['sid'];
$user = $_POST['user'];
$psw = $_POST['psw'];


$academic_year = $_POST['academic_year'];
$degree = $_POST['degree'];

$valid=false;
/*
$A=($fnameErr == $lnameErr);
$B=($idErr == $ssnErr);
$C=($userErr==$pswErr);
//$valid=(($A && $B) && $C);
*/

if($valid){
$query1 = "insert into students values ('$sid','$ssn','$fname','$lname','$academic_year','$degree')";
$result1 = mysqli_query($conn,$query1);

$query2 = "insert into studUsers values ('$user','$sid','$psw')";
$result2 = mysqli_query($conn,$query2);
}

if ($valid){

echo "Student Added Successfully to the System";

}
/*
else{
echo $fnameErr;
echo"<br>";
echo $lnameErr;
echo"<br>";
echo $idErr;
echo"<br>";
echo $ssnErr;
echo"<br>";
echo $userErr;
echo"<br>";
echo $pswErr;
}
*/

else{
echo "byee";
}

mysqli_close($conn);
?>
<br>
<a href="welcomePage.html">Back to Welcome Page</a>
</body>

