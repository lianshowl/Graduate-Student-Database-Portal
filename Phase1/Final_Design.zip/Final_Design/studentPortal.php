<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Student Portal</title>
  <link rel="stylesheet" type="text/css" href="style.css" />
  <style>
  ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 200px;
    background-color: #f1f1f1;
}

li a {
    display: block;
    color: #000;
    padding: 8px 16px;
    text-decoration: none;
}

/* Change the link color on hover */
li a:hover {
    background-color: navy;
    color: white;
}
  </style>
  
</head>
<body> 
<h2>Welcome!</h2>  
  <p></p>
<ul>
  <li><a href="main.html">Course Registration</a></li>
  <li><a href="transcript.php">View Transcript</a></li>
  <li><a href="ip.php">View/Drop Currently Registered Classes</a></li>
  <li><a href="weekSchedule.php">View Schedule</a></li>
  <li><a href="studentLogin.php">Log out</a></li>
</ul>
<br>
  </body>
</html>
