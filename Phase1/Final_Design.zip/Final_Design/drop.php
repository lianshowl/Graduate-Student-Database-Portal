<?php
session_start();
?>
 
<html>
<head>
<title>Drop</title>
</head>
<body>

<?php
$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password,$dbname);
if (!$conn) {
die("Connection failed: ". mysqli_connect_error());
}
$crn= $_POST['drop'];
$sid=$_SESSION["sid"];
$query = "delete from transcript where sid='$sid' and crn='$crn'";
$result = mysqli_query($conn,$query);
if ($result){
echo "You successfully dropped the course";
}
else{
echo "Error";
}
mysqli_close($conn);
?>
<br>
<a href="main.html">Back to Course Search Page</a>
</body>
