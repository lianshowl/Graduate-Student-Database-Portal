<html>
<head>
<title>Search Result</title>
</head>

<body>

Search Again:

<form method="post" action="gscourse.php">
 <input type="search" name="search">
 <input type="submit" value="Submit">
</form>

<?php

session_start();

$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password,$dbname);

if (!$conn) {
        die("Connection failed: ". mysqli_connect_error());
}
 
$year = $_POST["year"];
$day = $_POST["day"];
$start = $_POST["start"];
$end = $_POST["end"];
$fid = $_POST["fid"];
$sem = $_POST["sem"];
$crn = $_SESSION["crn"];

$query = "INSERT INTO courseOffer VALUES ('$crn', '$day', '$start', '$end', '$sem', '$year', '$fid')";

if (mysqli_query($conn, $query)) {
	echo "Course added correctly";
}
else {
	echo "Course not added" . mysqli_error($conn);
}

mysqli_close($conn);
?>

<br>

<a href="gs.html">Return to Main Page</a>

</body>

</html>
