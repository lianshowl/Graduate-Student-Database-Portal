<?php
$servername = "localhost";
$username = "team9";
 $password = "2wepmBKv";
 $dbname = "team9";
$conn = mysqli_connect($servername, $username, $password, $dbname);
 if (!$conn) {
 die("Connection failed: ". mysqli_connect_error());
 }

$sid=$_POST["search"];


?>
<html> 
<body>
<div class="container" style="width:700px;">  
                <h3 align="center">Your Transcript</h3><br />  
                <?php

		                 $query = "SELECT fname,lname, academic_year,degree FROM students WHERE students.sid = '$sid'";
                $result = mysqli_query($conn, $query);
		 $row = mysqli_fetch_assoc($result);
                echo "<h3> Name: " .$row["fname"]. " " .$row["lname"]. "</br> Major: " .$row["degree"]. " Year: " .$row["academic_year"]. "</h3>";  
                $query = "SELECT transcript.crn,sem,yr,grade,courseNum,dept,numCredit,title FROM transcript,catalog WHERE transcript.sid = '$sid'
		            and catalog.crn=transcript.crn ORDER BY crn ASC";
                $result = mysqli_query($conn, $query); 
                
              echo "<table border='1'>
              <tr>
              <th>CRN</th>
	            <th>Department</th>
	            <th>Course Number</th>
              <th>Title</th>
	            <th>Credit Hours</th>
              <th>Semester</th>
              <th>Year</th>
              <th>Grade</th>
              </tr>";
              if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
              echo "<tr>";
              echo "<td>" . $row['crn'] . "</td>";
              echo "<td>" . $row['dept'] . "</td>";
	            echo "<td>" . $row['courseNum'] . "</td>";
              echo "<td>" . $row['title'] . "</td>";
	            echo "<td>" . $row['numCredit'] . "</td>";	
              echo "<td>" . $row['sem'] . "</td>";
              echo "<td>" . $row['yr'] . "</td>";
              echo "<td>" . $row['grade'] . "</td>";
              echo "</tr>";
                      }
              echo "</table>";
                }
                ?>
              
              <?php
              $query2 = "SELECT  sum(catalog.numCredit)as total FROM transcript,catalog WHERE
            transcript.sid = '$sid' AND (transcript.grade = 'A' OR transcript.grade ='A-' OR 
            transcript.grade ='B+' OR transcript.grade ='B' 
            OR transcript.grade ='B-' OR transcript.grade ='C+' 
            OR transcript.grade ='C') and catalog.crn=transcript.crn";
            $result2 = mysqli_query($conn, $query2); 
	 	              
            if($result2)  
             {  
		        $row1 = mysqli_fetch_assoc($result2);
		        $total=$row1["total"];                
		        echo mysql_result($result2);
            if($row1["total"]==0){
                  $total =0;
              }
                     echo "<h3>Number of Credits: " . $total . "</h3>";
              }


              //gpa calculation
              $query3 = "SELECT catalog.numCredit, transcript.grade
               FROM transcript,catalog WHERE
               transcript.sid = '$sid' and catalog.crn=transcript.crn";
            $result3 = mysqli_query($conn, $query3);
            $sum=0;
            if (mysqli_num_rows($result3) > 0){
			while ($row3 = mysqli_fetch_assoc($result3)){
			$grade=$row3["grade"];
			$credit=$row3["numCredit"];
			if ($grade=="A"){
			$grade=4;
			}
			else if($grade=="A-"){
			$grade=3.7;
			}
			else if($grade=="B+"){
			$grade=3.3;
			}
			else if($grade=="B"){
			$grade=3;
			}
			else if($grade=="B-"){
			$grade=2.7;
			}
			else if($grade=="C+"){
			$grade=2.3;
			}
			else if($grade=="C"){
			$grade=2;
			}
			else{
			$grade=0;
			}
	
			$sum=$sum+$grade*$credit;
			}
			
			}

		$query4 = "SELECT sum(catalog.numCredit) as totalCred
               FROM transcript,catalog WHERE
               transcript.sid = '$sid' and catalog.crn=transcript.crn";
		 $result4 = mysqli_query($conn, $query4);
		$row4 = mysqli_fetch_assoc($result4);
			$gpa=$sum/$row4["totalCred"];			
			 echo "<h2>GPA: " . $gpa . "</h2>";
             
              ?>
		</br>
		</br>
                <a href="studentPortal.php">Back to Student Portal</a>

</body>                  
</html>
