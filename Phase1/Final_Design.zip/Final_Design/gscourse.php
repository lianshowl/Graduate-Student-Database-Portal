<html>
<head>
<title>Search Result</title>
</head>

<body>

<?php

session_start();

$crn = $_POST["search"];
$_SESSION["crn"] = $crn;

$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password,$dbname);

if (!$conn) {
        die("Connection failed: ". mysqli_connect_error());
}

// Query for finding course
$query1 = "SELECT * FROM catalog WHERE crn='$crn'";
$result1 = mysqli_query($conn,$query1);

// Displays queries
if (mysqli_num_rows($result1) > 0) {
        echo "<h2>Courses with Matching Course Number</h2>";
        echo "<table border='1'>
              <tr>
              <th>Dept</th>
              <th>Course Number</th>
              <th>Title</th>

              </tr>";
        while ($row = mysqli_fetch_assoc($result1)) {
              echo "<tr>";
              echo "<td>" . $row['dept'] . "</td>";
              echo "<td>" . $row['courseNum'] . "</td>";
              echo "<td>" . $row['title'] . "</td>";
              echo "</tr>";
              echo "</table>";
                echo  "<form method='post' action='gsAddCourse.php'>
                Year: <input type='number' name='year' min='17' max='20'><br>
                Day: <input type='text' value='M-F' name='day'><br>
                Start Time: <input type='text' name='start'><br>
                End Time: <input type='text' name='end'><br>
                Faculty ID: <input type='text' value='0000' name='fid'><br>
                Semester: <input type='search' name='sem'>
		<select name='sem'>
		<option value='f'>Fall</option>
		<option value='s'>Spring</option>
		</select><br>
                <input type='submit' value='Add Course to Schedule'>
                </form>";
        }
}
else {
        echo "No results match your search";
}

mysqli_close($conn);
?>

<br>

<a href="gs.html">Return to Main Page</a>

</body>

</html>
