<?php
session_start();
?>

<html>
<head>
<title>Your Schedule</title>
</head>
<body>

<?php

$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password,$dbname);
if (!$conn) {
die("Connection failed: ". mysqli_connect_error());
}

$sid=$_SESSION["sid"]; 
$sem="s";
$yr="19";

$query = "select catalog.crn,catalog.courseNum, catalog.title,
catalog.dept,courseOffer.sem,courseOffer.yr,courseOffer.cday,courseOffer.startTime,courseOffer.endTime
from transcript,courseOffer,catalog where transcript.sid='$sid' and transcript.sem='s'
and transcript.crn=catalog.crn and transcript.yr='19' and catalog.crn=courseOffer.crn
and courseOffer.sem='s' and courseOffer.yr='19'";
$result = mysqli_query($conn,$query);

if (mysqli_num_rows($result) > 0){
while ($row = mysqli_fetch_assoc($result)){

echo "CRN:" . $row["crn"]. "<br>";
echo "Title: " . $row["title"]." <br>".$row["dept"]. " " .$row["courseNum"]. "<br>";
echo "Day: ".$row["cday"]." Time: ". $row["startTime"]." " . $row["endTime"]."<br>";
//echo "Term: ". $row["sem"]." " . $row["yr"]."<br><hr>";
echo "<hr>";
}
} else {
     echo "You are not registered for any classes this term!";
  }

mysqli_close($conn);
?>
<br>
<a href="studentPortal.php">Back to Student Portal Page</a>
</body>
