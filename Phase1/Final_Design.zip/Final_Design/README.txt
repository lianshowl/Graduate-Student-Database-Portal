Database Systems Project REGS Write Up
Team 9
Members: Lian Showl, Shiva Omrani, Matthew Gilmore

Access our website using our link below:
http://seasdb.seas.gwu.edu/~team9/project/welcomePage.html

3/29/18

Click on the hyperlink to login in as, graduate secretary, faculty, or student.

To Login as a Graduate Secretary:

Username	Password
jpreston	janice1
hkingsman	harry1

The graduate secretary can search for a student to view their transcript by SID, the graduate secretary can also search for a student and alter their course grade by entering the student�s SID, the CRN of the class, and the semester and year. The graduate secretary can also search for a pre-existing course to add from the catalog with certain days, times, and faculty member to teach it to the table called �courseOffer�.

To Login as a Faculty:

Username	Password
dsmith		dennis1
fthompson	fiona1
taiden		tara1
aparker		avery1
mwazoski	mike1
alincoln	abraham1
gwashington	george1
jadams		john1
jmadison	james1
bfranklin	benjamin1
msteffens	mary1
ajarret		ada1
hgordon		hayden1
wchurchill	winston1
njames		newton1
tsnyder		snyder1
owilcott	wilcott1
hbaretta	baretta1
themmings	hemmings1
glucas		lucas1
btodd		todd1
lalver		alver1
pvora		poorvi37

A faculty member can see students who were/are in the classes they teach and can modify that student�s grade.

To Login as a Student: 

Username	Password
paulmccartney	mccartney1
georgeharrison	harrison1
lianshowl	lian123
somrani	shiva88

A student can register for classes, drop their classes, search for previous class schedules, and view their transcripts.

