<?php
$servername = "localhost";
$username = "team9";
 $password = "2wepmBKv";
 $dbname = "team9";
$conn = mysqli_connect($servername, $username, $password, $dbname);
 if (!$conn) {
 die("Connection failed: ". mysqli_connect_error());
 }
 
session_start(); 
 $fid=$_SESSION["fid"];
echo"<h2>Your Classes:</h2>";

  $query = "SELECT * FROM courseOffer as o, catalog as c WHERE o.fid = '$fid' AND o.crn=c.crn ";
                $result = mysqli_query($conn, $query); 
                
                echo "<table border='1'>
              <tr>
              <th>CRN</th>
              <th>Title</th>
              <th>Semester</th>
              <th>Year</th>
              </tr>";
              if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
              echo "<tr>";
              echo "<td>" . $row['crn'] . "</td>";
             $course = $row['crn'];
              echo "<td>" . $row['title'] . "</td>";
              echo "<td>" . $row['sem'] . "</td>";
              echo "<td>" . $row['yr'] . "</td>";
              echo "</tr>";
                      }
              echo "</table>";
                }

              $q = "SELECT s.sid, t.crn, t.sem, t.yr, fname, lname FROM students as s, transcript as t WHERE t.sid=s.sid AND t.crn='$course' AND t.grade = 'IP'";
              $res = mysqli_query($conn, $q);
              echo "<table border='1'>
              <tr>
              <h2>Students in Your Class</h2>
              <th>SID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>CRN</th>
              <th>Semester</th>
              <th>Year</th>
              </tr>";
              if(mysqli_num_rows($res) > 0)  
                {  
                     while($subrow = mysqli_fetch_array($res))  
                     {  
              echo "<tr>";
              echo "<td>" . $subrow['sid'] . "</td>";
              echo "<td>" . $subrow['fname'] . "</td>";
              echo "<td>" . $subrow['lname'] . "</td>";
              echo "<td>" . $subrow['crn'] . "</td>";
              echo "<td>" . $subrow['sem'] . "</td>";
              echo "<td>" . $subrow['yr'] . "</td>";
              echo "</tr>";
                      }
              echo "</table>";
                } 
                
                ?>  
<html>
<body>
<h2>Change Grade with the Info Above</h2>
<form method="post" action="facGrade.php">
  SID: <input type="search" name="sid">
  CRN: <input type="search" name="crn"><br>
  Semester: <input type="search" name="sem">
  Year: <input type="search" name="year"><br>
  <input type="submit" value="Submit">
</form>
</br>
</br>
<a href="facPage.html">Back to Faculty Page</a>
</body>                  
</html>