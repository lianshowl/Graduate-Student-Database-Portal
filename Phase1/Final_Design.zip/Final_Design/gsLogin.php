<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Graduate Secretary Login</title>
  <link rel="stylesheet" type="text/css" href="style.css" />
   <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta+Stencil">
<style>
  .w3-allerta {
  font-family: "Allerta Stencil", Sans-serif;
}
</style>
</head>
<?php
// remove all session variables
session_unset(); 

// destroy the session 
session_destroy(); 
?>
<body>
<div class="w3-container w3-black w3-center w3-allerta">
  <p class="w3-xlarge">Graduate Secretary Login</p>
</div>
  <p></p>
 <form method="post" action="processGS.php"> 
<h2>Please Login</h2></br>
Graduate Secretary Username:<br>
<input type="text" required="required" id="user" name="user" /><br />
Password:<br>
  <input type="password" required="required" id="psw" name="psw">
<input type="submit" name="login" style="margin-top:5px;" class="btn btn-success" value="Submit" />  
  </form>
<br>
</br>
 </br>
  <a href="welcomePage.html">Back to Welcome Page</a>
  </body>
</html>