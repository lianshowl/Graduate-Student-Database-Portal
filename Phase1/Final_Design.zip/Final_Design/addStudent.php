<?php
session_start();
?>

<html>
<head>
<title>Adding a Student to the System</title>
</head>
<body>

<?php

$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password,$dbname);
if (!$conn) {
die("Connection failed: ". mysqli_connect_error());
}


$fname = $_POST['fname'];
$lname = $_POST['lname'];
$ssn = $_POST['ssn'];
$academic_year = $_POST['academic_year'];
$sid = $_POST['sid'];
$degree = $_POST['degree'];
$user = $_POST['user'];
$psw = $_POST['psw'];



$query1 = "insert into students values ('$sid','$ssn','$fname','$lname','$academic_year','$degree')";
$result1 = mysqli_query($conn,$query1);

$query2 = "insert into studUsers values ('$user','$sid','$psw')";
$result2 = mysqli_query($conn,$query2);


if ($result2 && $result1){

echo "Student Added Successfully to the System";

}

else{
echo "Invalid entry, please check your input";
}

mysqli_close($conn);
?>
<br>
<a href="welcomePage.html">Back to Welcome Page</a>
</body>

