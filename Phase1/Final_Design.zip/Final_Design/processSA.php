<?php

session_start();

$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
die("Connection failed: ". mysqli_connect_error());
}
        if(isset($_POST['user'])){
                $id = $_POST['user'];
                $password = $_POST['psw'];

                // query the database for user
        $sql = "SELECT user,psw FROM saUsers WHERE user = '$id'
            AND  psw = '$password' LIMIT 1";
        $result = mysqli_query($conn,$sql);
        //echo $result;
        while($row = mysqli_fetch_array($result)) {
            $success = true;
          }
	if($success==false){
          echo '<script>alert("The username or password are incorrect! Please try again.")</script>';
          echo '<script> window.location="saLogin.php"</script>';
        }
	else
	{
            echo '<script>alert("Login successful!")</script>';
            echo '<script> window.location="saPortal.php"</script>';
        }

    }

?>



