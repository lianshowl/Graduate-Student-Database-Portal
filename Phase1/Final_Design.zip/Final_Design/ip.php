<?php
session_start();
?>

<html>
<head>
<title>Currently Registered Classes</title>
</head>
<body>

<?php

$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password,$dbname);
if (!$conn) {
die("Connection failed: ". mysqli_connect_error());
}

$sid=$_SESSION["sid"];
 

$query = "select transcript.crn,transcript.grade, catalog.courseNum, catalog.title,
catalog.dept, catalog.numCredit, transcript.sem,transcript.yr
from transcript,catalog where transcript.sid='$sid' and transcript.grade='IP'
and transcript.crn=catalog.crn";
$result = mysqli_query($conn,$query);
if (mysqli_num_rows($result) > 0){
//output data of each row
while ($row = mysqli_fetch_assoc($result)){
echo "CRN: ".$row["crn"]. "<br> Title:" . $row["title"]." <br>".$row["dept"]. " " .$row["courseNum"]. "<br>";
echo "Credit Hours: ".$row["numCredit"]."<br>";
echo "Term: ". $row["sem"]." " . $row["yr"]."<br>";
echo ("<form method='post' action='drop.php'>");
$thisCRN=$row["crn"];
echo("Click on the button with CRN below to drop the course: <br><input type='submit' value='$thisCRN' name='drop' /><hr>");

}
} else {
     echo "You are not currently registered for any classes!";
  }

mysqli_close($conn);
?>
<br>
<a href="studentPortal.php">Back to Student Portal Page</a>
</body>
