<?php
session_start();
?>

<html>
<head>
<title>test</title>
</head>
<body>

<?php
$servername = "localhost";
$username = "team9";
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password,$dbname);
if (!$conn) {
die("Connection failed: ". mysqli_connect_error());
}
echo "hi<br>";
$sid=$_SESSION["sid"];

echo "<pre>";
print_r($_SESSION);
echo "</pre>";

mysqli_close($conn);
?> 
<br>
<a href="studentPortal.php">Back to Student Portal</a>
</body>
