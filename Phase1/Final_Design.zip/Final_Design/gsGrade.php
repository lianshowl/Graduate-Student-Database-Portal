<html>
<head>
<title>Search Result</title>
</head>

<body>

Search Again:

<form method="post" action="gsGrade.php">
  SID: <input type="search" name="sid"><br>
  CRN: <input type="search" name="crn">
  Semester: <input type="search" name="sem">
  Year: <input type="search" name="year">
  <input type="submit" value="Submit">
</form>

<?php

session_start();

$servername = "localhost";
$username = "team9"; 
$password = "2wepmBKv";
$dbname = "team9";
$conn = mysqli_connect($servername, $username, $password,$dbname);

if (!$conn) {
        die("Connection failed: ". mysqli_connect_error());
}

$sid =$_POST["sid"];
$crn =$_POST["crn"];
$sem =$_POST["sem"];
$yr =$_POST["year"];

$query = "SELECT * FROM transcript WHERE crn='$crn' AND sid='$sid'
AND sem='$sem' AND yr='$yr'";
$result = mysqli_query($conn,$query);

if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
		 echo "<table border='1'>
              <tr>
              <th>CRN</th>
              <th>Semester</th>
              <th>Year</th>
              <th>Grade</th>
              </tr>";
         echo "<tr>";
              echo "<td>" . $row['crn'] . "</td>";
              echo "<td>" . $row['sem'] . "</td>";
              echo "<td>" . $row['yr'] . "</td>";
              echo "<td>" . $row['grade'] . "</td>";
              echo "</tr>";
              echo "</table>";
		echo "<form method='post' action='gsAddGrade.php'>
		Enter Grade: <input type='text' name='grade'>
		<input type='submit' value='Submit'>
		</form>";
		$_SESSION["sid"] = $sid;
		$_SESSION["crn"] = $crn;
		$_SESSION["sem"] = $sem;
		$_SESSION["yr"] = $yr;
	}
}
else {
       echo "An error occurred. Try entering all fields.";
}

?>

<br>
<br>

<a href="gs.html">Return to Main Page</a>

</body>

</html>
